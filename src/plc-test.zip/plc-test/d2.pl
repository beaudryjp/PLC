a = 3;
b = 12;
if (1<=a && a<=5 || (b=a) > 10 || ! b == a ) {
     a=b;
}
print(a*b);