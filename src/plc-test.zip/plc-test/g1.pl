i=1;
do {
    suma = suma + i;
    i = i+1;
} while (i<10) ;
print (suma);

