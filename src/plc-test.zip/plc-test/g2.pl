do {
    do {
        do 
            suma = suma+a+b+c;
        while (c=c+1 < 10);
    } while (b=b+1 < 10);
} while ( a=a+1 < 10 );
print(suma);        

