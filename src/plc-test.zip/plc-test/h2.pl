for (i=1; i<10; i=i+1) {
    k=2;
    for(j=1; j<k; j=j+i) {
        k = k*i;
        x = x+i;
    }    
}    
print(x);
